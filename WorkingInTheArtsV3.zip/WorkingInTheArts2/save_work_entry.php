<?php
session_start();
include('db.php');

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $description = $_POST['description'];
    $client_name = $_POST['client_name'];
    $client_address = $_POST['client_address'];
    $client_vat = $_POST['client_vat'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $hours_worked = $_POST['hours_worked'];
    $gross_wage = $_POST['gross_wage'];

    // Convert gross wage to days worked
    $days_worked = $gross_wage / 79.63;

    // Handle file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["contract_photo"]["name"]);
    if (move_uploaded_file($_FILES["contract_photo"]["tmp_name"], $target_file)) {
        $photo_url = $target_file;
    } else {
        echo "Sorry, there was an error uploading your file.";
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO work_entries (user_id, description, client_name, client_address, client_vat, start_date, end_date, hours_worked, gross_wage, days_worked, photo_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssssddds", $user_id, $description, $client_name, $client_address, $client_vat, $start_date, $end_date, $hours_worked, $gross_wage, $days_worked, $photo_url);
    $stmt->execute();

    if ($stmt->error) {
        echo "Error: " . $stmt->error;
    } else {
        header("Location: dashboard.php");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
