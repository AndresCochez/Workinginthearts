document.getElementById('itsme-login').addEventListener('click', function() {
    // Mocking ItsMe login process
    window.location.href = 'job_selection.html';
});