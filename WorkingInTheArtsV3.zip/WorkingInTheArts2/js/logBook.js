function deleteEntry(entryId) {
    if (confirm('Weet je zeker dat je het ingevoerde werk wil verwijderen?')) {
        $.post('delete_entry.php', {
            delete_id: entryId
        }, function(data) {
            if (data.success) {
                alert('Entry deleted successfully.');
                location.reload(); // Reload the page to update the list
            } else {
                alert('Error deleting entry.');
            }
        }, 'json');
    }
}

function updateEntryClasses() {
    // Select all entries
    const entries = document.querySelectorAll('.lbEntry');
    entries.forEach((entry, index) => {
        // Find the .lbDesc element within the entry
        const desc = entry.querySelector('.lbDesc');
        // Ensure desc exists before attempting to modify it
        if (desc) {
            // Remove existing specialClass from .lbDesc
            desc.classList.remove('specialClass');
            // Add specialClass to .lbDesc of every second entry
            if (index % 2 == 1) {
                desc.classList.add('specialClass');
            }
        }
    });
}

window.onload = function() {
    updateLayout();
};

window.onresize = function() {
    updateLayout();
};

function updateLayout() {
    var contentHeight = window.innerHeight - document.querySelector('.headerNav').offsetHeight - document.querySelector('.navbar').offsetHeight;
    document.querySelector('.content').style.height = contentHeight + 'px';
}