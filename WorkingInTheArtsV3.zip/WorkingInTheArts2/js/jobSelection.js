document.addEventListener('DOMContentLoaded', function() {
    const jobSelect = document.getElementById('job_type');
    const radios = document.querySelectorAll('input[type="radio"][name="category"]');

    function updateJobOptions(category) {
        const options = {
            artistiek: ['Muzikant(e)', 'Schrijfster/Schrijver', 'Danser(es)', 'Actrice/Acteur', 'Kunstschilder(es)', 'Beeldhouw(st)er', 'Kunstfotograaf/fotografe', 'Circusartiest(e)'],
            'technisch-artistiek': ['Beeldtechnicus', 'Geluidstechnicus', 'Grader bij een fictiereeks', 'Motion designer bij een animatiefilm', 'Hoofd atelier in de opera'],
            'ondersteunend-artistiek': ['Casting Director', 'Dramaturg(e)', 'Scenograaf(e)', 'Producer', 'Curator', 'Assistent-regisseur']
        };

        // Clear current options
        jobSelect.innerHTML = '';

        // Append new options
        options[category].forEach(job => {
            const option = document.createElement('option');
            option.value = job.toLowerCase().replace(/\s+/g, '-');
            option.textContent = job;
            jobSelect.appendChild(option);
        });
    }

    // Initialize with the default checked value
    const initialCategory = document.querySelector('input[type="radio"][name="category"]:checked').value;
    updateJobOptions(initialCategory);

    // Function to change the background of the selected radio button's label
    function updateLabelBackground() {
        radios.forEach(input => {
            input.parentElement.classList.remove('selected'); // Remove from all first
        });
        const selectedRadio = document.querySelector('input[type="radio"][name="category"]:checked');
        selectedRadio.parentElement.classList.add('selected'); // Add to the checked one
    }

    // Call to set initial background on page load
    updateLabelBackground();

    // Event listener for changes on radios
    radios.forEach(radio => {
        radio.addEventListener('change', function() {
            updateJobOptions(this.value);
            updateLabelBackground(); // Update background color when radio changes
        });
    });
});
