<?php
session_start();
include('db.php');

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    header("Location: register.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $job_type = $_POST['job_type'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE users SET job_type = ? WHERE user_id = ?");
    $stmt->bind_param("si", $job_type, $user_id);
    $stmt->execute();

    if ($stmt->error) {
        echo "Error: " . $stmt->error;
    } else {
        $_SESSION['job_type'] = $job_type;
        header("Location: dashboard.php");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
