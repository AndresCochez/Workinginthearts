<?php
session_start();
include('db.php'); // Ensure the database connection is properly set

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Fetch user details
$stmt = $conn->prepare("SELECT name FROM users WHERE user_id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
if (!$user = $user_result->fetch_assoc()) {
    echo "Failed to fetch user details.";
}

// Fetch progress details
$stmt = $conn->prepare("SELECT SUM(days_worked) AS worked_days FROM work_entries WHERE user_id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$progress_result = $stmt->get_result();
$progress = $progress_result->fetch_assoc();
$worked_days = $progress['worked_days'] ?? 0;
$progress_percentage = ($worked_days / 156) * 100; // Assuming 156 is the target

// Fetch the last six log entries
$stmt = $conn->prepare("SELECT start_date, description, gross_wage FROM work_entries WHERE user_id = ? ORDER BY start_date DESC LIMIT 6");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$logbook_entries_result = $stmt->get_result();
$logbook_entries = [];
while ($entry = $logbook_entries_result->fetch_assoc()) {
    $logbook_entries[] = $entry;
}

// Fetch the nearest upcoming reminder
$stmt = $conn->prepare("SELECT reminder_text, reminder_date, reminder_time FROM reminders WHERE user_id = ? AND reminder_date >= CURDATE() ORDER BY reminder_date ASC, reminder_time ASC LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$reminder_result = $stmt->get_result();
$reminder = $reminder_result->fetch_assoc();

// Fetch current month's work days
$current_month = date('Y-m');
$stmt = $conn->prepare("SELECT work_date FROM agenda WHERE user_id = ? AND work_date LIKE ?");
$month_param = $current_month . '%';
$stmt->bind_param("is", $user_id, $month_param);
$stmt->execute();
$agenda_result = $stmt->get_result();
$work_dates = [];
while ($row = $agenda_result->fetch_assoc()) {
    $work_dates[] = $row['work_date'];
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/dashboard.css?v=1.07">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link href='https://fonts.googleapis.com/css?family=Libre Franklin' rel='stylesheet'>
    <title>Dashboard - Working In The Arts</title>
</head>
<body>
<div class="headerNav">
    <img src="images/LogoWITA.png" class="LogoWITA" alt="WorkingInTheArts logo">
    <img src="images/LogoBE.png" class="LogoBE" alt="Overheid Logo">
</div>

<h1>Hallo, <span class="username"><?php echo htmlspecialchars($user['name']); ?></span></h1>
<div class="dashboard">
    <div class="dash1">
        <div class="d1line1">
            <span class="dashTitle">Gewerkte Dagen</span>
            <img src="images/iconMedal.png" alt="Medal Icon" class="medalIcon">
        </div>
        <span class="dagenGewerkt"><?php echo number_format($worked_days, 2, ',', '.'); ?></span>
        <div class="progress-bar">
            <div class="progress" style="width: <?php echo round($progress_percentage, 2); ?>%;"></div>
        </div>
        <span class="subTitle">Vooruitgang</span>
    </div>
    <div class="dashWrap1">
        <div class="dash2">
            <!-- Display the most recent entry -->
            <?php if (!empty($logbook_entries)): ?>
                <span class="dashTitle2">Recent ingevoerd</span>
                <p class="wage">€<?php echo number_format($logbook_entries[0]['gross_wage']); ?></p>
                <p class="desc"><?php echo htmlspecialchars($logbook_entries[0]['description']); ?></p>
                <p class="datum"><?php echo date('d/m/Y', strtotime($logbook_entries[0]['start_date'])); ?></p>
            <?php endif; ?>
        </div>
        <div class="dash3" onclick="window.location.href='reminders_page.php';" style="cursor: pointer;">
            <span class="dashTitle3">Reminders</span>
            <?php if ($reminder): ?>
                <p class="reminderDetails"><?php echo htmlspecialchars($reminder['reminder_text']); ?></p>
                <p class="reminderTime"><?php echo date('H:i', strtotime($reminder['reminder_time'])); ?> uur</p>
                <p class="reminderDate"><?php echo date('d/m', strtotime($reminder['reminder_date'])); ?></p>
            <?php else: ?>
                <p class="reminderNone">Je hebt geen reminders.</p>
                <p class="reminderSet">Zet reminder</p>
            <?php endif; ?>
        </div>
    </div>
    <div class="dashWrap2">
        <div class="dash4" onclick="window.location.href='logbook.php';" style="cursor: pointer;">
            <span class="dashTitle4">Logboek</span>
            <div class="logbook-entries">
                <?php foreach ($logbook_entries as $index => $entry): ?>
                    <div class="lbItem">
                        <span class="lbWage">€<?php echo number_format($entry['gross_wage'], 0); ?></span>
                        <!-- Check if the entry is 2nd, 4th, or 6th to add a special class -->
                        <span class="lbDesc<?php if (($index + 1) % 2 == 0) echo ' specialClass'; ?>">
                            <?php echo htmlspecialchars($entry['description']); ?>
                        </span>
                        <span class="lbDate"><?php echo date('d/m', strtotime($entry['start_date'])); ?></span>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($logbook_entries)): ?>
                    <div class="lbItem">No entries found.</div>
                <?php endif; ?>
            </div>
        </div>
        <div class="dash5" onclick="window.location.href='agenda.php';" style="cursor: pointer;">
            <span class="dashTitle5">Agenda</span>
            <span class="dashMonth">        <?php
        $current_month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
        echo date('F Y', strtotime($current_month . '-01'));
        ?></span>
            <div class="calendar">
                <?php
                $days_in_month = date('t');
                $today = date('Y-m-d');

                for ($day = 1; $day <= $days_in_month; $day++) {
                    $date = $current_month . '-' . str_pad($day, 2, '0', STR_PAD_LEFT);
                    $class = '';

                    if ($date == $today) {
                        $class = 'today';
                    } elseif (in_array($date, $work_dates)) {
                        $class = ($date < $today) ? 'past-worked-day' : 'working-day';
                    }

                    echo "<div class='day $class' data-date='$date'>$day</div>";
                }
                ?>
            </div>
        </div>
    </div>
</div>

<div class="navbar">
    <div class="navIcons"> 
        <a href="data_entry.html"><img src="images/navWork.png" alt="" class="navWork"></a>
        <img src="images/navDashActive.png" alt="navDashActive" class="navDash">
        <a href="settings.php"><img src="images/navSettings.png" alt="navSettings" class="navSettings"></a>
    </div>
</div>
</body>
</html>
