<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $reminder_text = $_POST['reminder_text'];
    $reminder_date = $_POST['reminder_date'];
    $reminder_time = $_POST['reminder_time'];

    $stmt = $conn->prepare("INSERT INTO reminders (user_id, reminder_text, reminder_date, reminder_time) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $reminder_text, $reminder_date, $reminder_time);
    if ($stmt->execute()) {
        $stmt->close();
        header("Location: reminders_page.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
        $stmt->close();
    }
}
?>
