<?php
session_start();
include('db.php');

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if email already exists
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "Email already registered.";
    } else {
        // Insert new user into the database
        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password);

        if ($stmt->execute()) {
            $_SESSION['user_id'] = $stmt->insert_id;
            $_SESSION['email'] = $email;
            $_SESSION['name'] = $name;
            header("Location: job_selection.html");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/register.css">
    <link href='https://fonts.googleapis.com/css?family=Libre Franklin' rel='stylesheet'>
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <title>Register - WorkingInTheArts</title>
</head>
<body>
    <div class="headerNav">
        <img src="images/LogoWITA.png" class="LogoWITA" alt="WorkingInTheArts logo">
        <img src="images/LogoBE.png" class="LogoBE" alt="Overheid Logo">
    </div>
    <img src="images/headerimg.png" alt="" class="headerimg">
    <div class="title">
        <h1>Maak je account aan.</h1>
        <h2>Registreer en start je reis bij Working in the Arts.</h2>
    </div>
    <div class="dashboard">
        <div class="dash1">
            <form method="post" action="register.php">
            <h1 class="formTitle">Registreren</h1>
                <div class="inputs">
                    <div class="d1line1">
                        <label for="name">Voornaam</label>
                        <input type="text" name="name" id="name" placeholder="John Doe" required>
                    </div>
                    <div class="d1line1">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" placeholder="voorbeeld@email.com" required>
                    </div>
                    <div class="d1line1">
                        <label for="password">Wachtwoord</label>
                        <input type="password" name="password" id="password" placeholder="●●●●●●●" required>
                    </div>
                </div>
                <div class="buttons">
                    <button type="submit" class="button">Registreer</button>
                    <a href="login.php" class="registerLink">Ik heb al een account.</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
