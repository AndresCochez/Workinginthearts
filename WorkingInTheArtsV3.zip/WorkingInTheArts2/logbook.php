<?php
session_start();
include('db.php');

ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Check for export action
if (isset($_GET['action']) && $_GET['action'] == 'export') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="logbook_entries.csv"');
    $output = fopen("php://output", "w");
    fputcsv($output, array('Entry ID', 'Start Date', 'Description', 'Gross Wage', 'Client Name'));

    $stmt = $conn->prepare("SELECT entry_id, start_date, description, gross_wage, client_name FROM work_entries WHERE user_id = ? ORDER BY start_date DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $stmt = $conn->prepare("DELETE FROM work_entries WHERE entry_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $delete_id, $user_id);
    if ($stmt->execute()) {
        $stmt->close();
        header("Location: logbook.php");
        exit();
    } else {
        echo "Error deleting record: " . $stmt->error;
        $stmt->close();
    }
}

$sort_order = isset($_GET['sort']) ? $_GET['sort'] : 'start_date DESC';
$filter_options = [
    'most_recent' => 'start_date DESC',
    'least_recent' => 'start_date ASC',
    'most_earned' => 'gross_wage DESC',
    'least_earned' => 'gross_wage ASC'
];
$sort_order = $filter_options[$sort_order] ?? 'start_date DESC';

$stmt = $conn->prepare("SELECT entry_id, start_date, description, gross_wage, client_name FROM work_entries WHERE user_id = ? ORDER BY $sort_order");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$entries = [];
while ($row = $result->fetch_assoc()) {
    $entries[] = $row;
}
$stmt->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/logbook.css?v=1.03">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link href='https://fonts.googleapis.com/css?family=Libre Franklin' rel='stylesheet'>
    <title>Logboek - Working In The Arts</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/logBook.js"></script>
</head>
<body>
    <div class="headerNav">
        <img src="images/LogoWITA.png" class="LogoWITA" alt="WorkingInTheArts logo">
        <img src="images/LogoBE.png" class="LogoBE" alt="Overheid Logo">
    </div>
    <div class="content">
    <div class="pageTitle">
        <h1>Logboek</h1>
        <a href="dashboard.php"><img src="images/iconBack.png" alt="" class="iconBack"></a>
    </div>
    <div class="filter">
        <form>
            <label for="sort">Filter:</label>
            <select id="sort" name="sort" onchange="this.form.submit()">
                <option value="most_recent" <?php echo $sort_order === 'start_date DESC' ? 'selected' : ''; ?>>Meest Recent</option>
                <option value="least_recent" <?php echo $sort_order === 'start_date ASC' ? 'selected' : ''; ?>>Minst Recent</option>
                <option value="most_earned" <?php echo $sort_order === 'gross_wage DESC' ? 'selected' : ''; ?>>Meest Verdiend</option>
                <option value="least_earned" <?php echo $sort_order === 'gross_wage ASC' ? 'selected' : ''; ?>>Minst Verdiend</option>
            </select>
        </form>
        <div class="exportButton">
            <a href="?action=export">Gegevens exporteren</a>
        </div>
    </div>
    <div class="entries">
        <?php
        $count = 0; // Initialize counter to zero
        foreach ($entries as $entry) :
            // Check if the count is odd (since it's zero-based, odd here means the 2nd, 4th, 6th... entries)
            $specialClass = ($count % 2 == 1) ? 'specialClass' : '';
        ?>
            <div class="lbEntry">
                <div class="lbEntry1">
                    <span class="lbDesc <?php echo $specialClass; ?>"><?php echo htmlspecialchars($entry['description']); ?></span>
                    <span class="lbDate"><?php echo date('d/m', strtotime($entry['start_date'])); ?></span>
                </div>
                <div class="lbEntryWage">
                    <span class="lbWage">€<?php echo number_format($entry['gross_wage'], 0); ?></span>
                </div>
                <div class="lbEntry2">
                    <span class="lbClientName"><?php echo htmlspecialchars($entry['client_name']); ?></span>
                    <img src="images/iconDelete.png" onclick="deleteEntry(<?php echo $entry['entry_id']; ?>)" alt="Delete" class="iconDelete">
                </div>
            </div>
        <?php
            $count++; // Increment the counter after each loop iteration
        endforeach;
        ?>
    </div>
    </div>
    <div class="navbar">
        <div class="navIcons">
            <a href="data_entry.html"><img src="images/navWork.png" alt="" class="navWork"></a>
            <img src="images/navDashActive.png" alt="navDashActive" class="navDash">
            <a href="settings.php"><img src="images/navSettings.png" alt="navSettings" class="navSettings"></a>
        </div>
    </div>
</body>

</html>