<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reminder_id'])) {
    $reminder_id = $_POST['reminder_id'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("DELETE FROM reminders WHERE reminder_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $reminder_id, $user_id);
    if ($stmt->execute()) {
        $stmt->close();
        header("Location: reminders_page.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
        $stmt->close();
    }
}
?>
