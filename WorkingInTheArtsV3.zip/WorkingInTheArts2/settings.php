<?php
session_start();
include('db.php'); // Ensure the database connection is properly set

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle POST requests for name or email updates
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && $_POST['action'] == 'editName' && isset($_POST['name'])) {
        $newName = $_POST['name'];
        $stmt = $conn->prepare("UPDATE users SET name = ? WHERE user_id = ?");
        $stmt->bind_param("si", $newName, $user_id);
        $stmt->execute();
        $stmt->close();
        $_SESSION['name'] = $newName; // Update session variable if needed
    } elseif (isset($_POST['action']) && $_POST['action'] == 'editEmail' && isset($_POST['email'])) {
        $newEmail = $_POST['email'];
        $stmt = $conn->prepare("UPDATE users SET email = ? WHERE user_id = ?");
        $stmt->bind_param("si", $newEmail, $user_id);
        $stmt->execute();
        $stmt->close();
        $_SESSION['email'] = $newEmail; // Update session variable if needed
    }
    header("Location: settings.php"); // Refresh the page to show the updated data
    exit();
}

$query = "SELECT name, job_type, profile_pic, email, receive_notifications FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Lowercase the entire string and then capitalize only the first letter
$formattedJobType = ucfirst(strtolower(str_replace(['-', '_'], ' ', $user['job_type'])));

$profilePic = $user['profile_pic'] ?: 'images/defaultpfp.png';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instellingen - Working In The Arts</title>
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/settings.css?v=1.04">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link href='https://fonts.googleapis.com/css?family=Libre Franklin' rel='stylesheet'>
    <script>
        function toggleEdit(field) {
            var display = document.getElementById(field + 'Display');
            var form = document.getElementById(field + 'Form');
            if (form.style.display === 'none') {
                form.style.display = 'block';
                display.style.display = 'none';
            } else {
                form.style.display = 'none';
                display.style.display = 'block';
            }
        }
    </script>
</head>
<body>
<div class="headerNav">
    <img src="images/LogoWITA.png" class="LogoWITA" alt="WorkingInTheArts logo">
    <img src="images/LogoBE.png" class="LogoBE" alt="Overheid Logo">
</div>
<h1>Instellingen</h1>


<div class="profilePanel">
    <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="profilePicture">
    <div class="userDetails">
        <span class="Name"><?php echo htmlspecialchars($user['name']); ?></span>
        <span class="Job"><?php echo htmlspecialchars($formattedJobType); ?></span>
    </div>
    <img src="images/WITAsmall.png" alt="" class="WITAlogo">
</div>
<h2>Account Gegevens</h2>
<!-- Name -->
<div class="panel">
    <img src="images/iconName.png" alt="" class="icon">
    <div id="nameDisplay" class="panelText"><?php echo htmlspecialchars($user['name']); ?></div>
    <form id="nameForm" style="display:none;" action="settings.php" method="post">
        <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
        <input type="hidden" name="action" value="editName">
        <button type="submit">Klaar</button>
    </form>
    <img src="images/iconEdit.png" alt="" class="iconEdit" onclick="toggleEdit('name')">
</div>
<!-- Email -->
<div class="panel">
    <img src="images/iconEmail.png" alt="" class="icon">
    <div id="emailDisplay" class="panelText"><?php echo htmlspecialchars($user['email']); ?></div>
    <form id="emailForm" action="settings.php" method="post" style="display:none;">
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        <input type="hidden" name="action" value="editEmail">
        <button type="submit">Klaar</button>
    </form>
    <img src="images/iconEdit.png" alt="" class="iconEdit" onclick="toggleEdit('email')">
</div>
<div class="panel panelJob">
    <img src="images/iconJob.png" alt="" class="icon">
    <h3 class="panelText"><?php echo htmlspecialchars($formattedJobType); ?></h3>
    <img src="images/iconEdit.png" alt="" class="iconEdit" onclick="toggleEdit('jobType')">
</div>
<h2>Algemene Instellingen</h2>
<div class="panel">
    <img src="images/iconNoti.png" alt="" class="icon">
    <h3 class="panelText">Meldingen Ontvangen</h3>
    <label class="switch">
        <input type="checkbox" id="notificationsToggle" <?php echo $user['receive_notifications'] ? 'checked' : ''; ?>>
        <span class="slider round"></span>
    </label>
</div>
<div class="panel">
    <img src="images/iconTaal.png" alt="" class="icon">
    <h3 class="panelText">Taal wijzigen</h3>
    <img src="images/iconArrow.png" alt="" class="iconArrow">
</div>
<div class="panel panelLogout">
    <img src="images/iconLogout.png" alt="" class="icon">
    <h3 class="panelText logout">Uitloggen</h3>
    <img src="images/iconArrow.png" alt="" class="iconArrow">
</div>
<div class="navbar">
    <div class="navIcons"> 
    <a href="data_entry.html"><img src="images/navWork.png" alt="" class="navWork"></a>
    <a href="dashboard.php"><img src="images/navDash.png" alt="navDashActive" class="navDash"></a>
    <img src="images/navSettingsActive.png" alt="navSettings" class="navSettings">
    </div>
</div>
<script>
document.getElementById('notificationsToggle').addEventListener('change', function() {
    var notificationStatus = this.checked ? 1 : 0;
    fetch('update_notifications.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'receive_notifications=' + notificationStatus
    })
    .then(response => response.text())
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));
});

document.getElementById('notificationsToggle').addEventListener('change', function() {
    var notificationStatus = this.checked ? 1 : 0;
    fetch('update_notifications.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'receive_notifications=' + notificationStatus
    })
    .then(response => response.text())
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));
});

// Redirect function for job panel click
function redirectToJobSelection() {
    window.location.href = 'job_selection.html';
}

// Event listener for the panelJob click
document.querySelector('.panelJob').addEventListener('click', redirectToJobSelection);

// Logout function
function logoutAndRedirect() {
    fetch('logout.php', { // Assuming 'logout.php' logs the user out
        method: 'POST'
    })
    .then(response => {
        if(response.ok) {
            window.location.href = 'index.html'; // Redirect on successful logout
        } else {
            throw new Error('Failed to log out.');
        }
    })
    .catch(error => console.error('Error:', error));
}

// Event listener for the logout panel click
document.querySelector('.panelLogout').addEventListener('click', logoutAndRedirect);
</script>
</body>
</html>
