<?php
session_start();
include('db.php');

if (isset($_POST['receive_notifications'])) {
    $receive_notifications = $_POST['receive_notifications'] == '1' ? 1 : 0;
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE users SET receive_notifications = ? WHERE user_id = ?");
    $stmt->bind_param("ii", $receive_notifications, $user_id);
    if ($stmt->execute()) {
        echo "Notification setting updated.";
    } else {
        echo "Error updating setting.";
    }
    $stmt->close();
}
?>