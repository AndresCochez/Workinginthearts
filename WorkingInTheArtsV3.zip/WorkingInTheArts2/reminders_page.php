<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Fetch reminders
$stmt = $conn->prepare("SELECT reminder_id, reminder_text, reminder_date, reminder_time FROM reminders WHERE user_id = ? ORDER BY reminder_date DESC, reminder_time DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$reminders_result = $stmt->get_result();
$reminders = [];
while ($reminder = $reminders_result->fetch_assoc()) {
    $reminders[] = $reminder;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/reminders_page.css?v=1.01">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link href='https://fonts.googleapis.com/css?family=Libre Franklin' rel='stylesheet'>
    <title>Reminders - Working In The Arts</title>
</head>
<body>
<div class="headerNav">
    <img src="images/LogoWITA.png" class="LogoWITA" alt="WorkingInTheArts logo">
    <img src="images/LogoBE.png" class="LogoBE" alt="Overheid Logo">
</div>
<div class="pageTitle">
    <h1>Reminders</h1>
    <a href="dashboard.php"><img src="images/iconBack.png" alt="" class="iconBack"></a>
</div>
<div class="reminderForm">
    <form action="handle_reminder.php" method="post">
        <h1 class="formTitle">Zet een reminder</h1>
        <div class="input1 inputpanel">
        <label for="reminder_text">Omschrijving</label>
        <input type="text" id="reminder_text" name="reminder_text" required>
        </div>
        <div class="wrap">
        <div class="input1 inputpanel">
        <label for="reminder_date">Reminder Datum</label>
        <input type="date" id="reminder_date" name="reminder_date" required>
        </div>
        <div class="input1 inputpanel">
        <label for="reminder_time">Reminder Tijd</label>
        <input type="time" id="reminder_time" name="reminder_time" required>
        </div>
        </div>
        <div class="buttons">
        <input type="submit" value="Zet Reminder" class="button">
        </div>
    </form>
</div>
<div class="remindersList">
    <?php foreach ($reminders as $reminder): ?>
        <div class="reminderItem">
            <div class="reminderWrap">
            <div class="reminderText">
            <p class="reminderTitle"><?php echo htmlspecialchars($reminder['reminder_text']); ?></p>
            <p class="reminderDetails"><?php echo date('d/m/Y', strtotime($reminder['reminder_date'])); ?> om <?php echo date('H:i', strtotime($reminder['reminder_time'])); ?></p>
            </div>
            <div class="reminderIcon">
                <img src="images/iconNoti.png" alt="" class="iconReminder">
            </div>
            </div>
            <form class="formList" action="delete_reminder.php" method="post" onsubmit="return confirm('Weet je zeker dat je deze reminder wilt verwijderen?');">
                <input type="hidden" name="reminder_id" value="<?php echo $reminder['reminder_id']; ?>">
                <button type="submit">Verwijderen</button>
            </form>
        </div>
    <?php endforeach; ?>
    <?php if (empty($reminders)): ?>
        <p class="noReminder">Geen reminders gezet.</p>
    <?php endif; ?>
</div>
<div class="navbar">
    <div class="navIcons">
        <a href="data_entry.html"><img src="images/navWork.png" alt="" class="navWork"></a>
        <img src="images/navDashActive.png" alt="navDashActive" class="navDash">
        <a href="settings.php"><img src="images/navSettings.png" alt="navSettings" class="navSettings"></a>
    </div>
</div>
</body>
</html>
