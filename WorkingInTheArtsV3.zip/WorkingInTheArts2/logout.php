<?php
session_start();
if (isset($_SESSION['user_id'])) {
    session_destroy(); // Destroy all session data
    echo 'Logged out successfully';
} else {
    header('HTTP/1.1 403 Forbidden');
    echo 'No session found or already logged out';
}
?>
