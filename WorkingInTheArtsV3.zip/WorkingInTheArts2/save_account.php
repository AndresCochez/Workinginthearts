<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include('db.php'); // Ensure this path is correct and the file is included

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password

    // Mock user ID for this example
    $user_id = uniqid('user_');

    $_SESSION['user_id'] = $user_id;
    $_SESSION['email'] = $email;

    // Save user data in the database
    $stmt = $conn->prepare("INSERT INTO users (user_id, name, email, age, password) VALUES (?, ?, ?, ?, ?)");
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    
    $bind = $stmt->bind_param("sssis", $user_id, $name, $email, $age, $password);
    if ($bind === false) {
        die('Bind failed: ' . htmlspecialchars($stmt->error));
    }

    $exec = $stmt->execute();
    if ($exec === false) {
        die('Execute failed: ' . htmlspecialchars($stmt->error));
    } else {
        header("Location: job_selection.html");
        exit();
    }

    $stmt->close();
} else {
    die('Invalid request method');
}

$conn->close();
?>
