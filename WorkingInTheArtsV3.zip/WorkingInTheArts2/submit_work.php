<?php
session_start();
include('db.php'); // Ensure you have a connection to the database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST['date'];
    $hours = $_POST['hours'];
    $description = $_POST['description'];

    // Handle file upload if there's a file
    if (!empty($_FILES['file']['name'])) {
        $file_name = $_FILES['file']['name'];
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_path = "uploads/" . $file_name;
        move_uploaded_file($file_tmp, $file_path);
    } else {
        $file_path = "";
    }

    // Insert data into the database
    $query = "INSERT INTO work_entries (user_id, date, hours, description, file_path) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('isiss', $_SESSION['user_id'], $date, $hours, $description, $file_path);
    $stmt->execute();

    if ($stmt->error) {
        echo "Error: " . $stmt->error;
    } else {
        echo "Work entry added successfully!";
        // Redirect or display a message
    }
    $stmt->close();
}

$conn->close();
?>
