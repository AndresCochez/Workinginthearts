<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Handle marking and unmarking work days
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['work_date']) && !empty($_POST['work_date'])) {
        $work_date = $_POST['work_date'];

        // Check if the date is already marked
        $stmt = $conn->prepare("SELECT COUNT(*) FROM agenda WHERE user_id = ? AND work_date = ?");
        $stmt->bind_param("is", $user_id, $work_date);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        if ($count > 0) {
            // Unmark the work day
            $stmt = $conn->prepare("DELETE FROM agenda WHERE user_id = ? AND work_date = ?");
            $stmt->bind_param("is", $user_id, $work_date);
        } else {
            // Mark the work day
            $stmt = $conn->prepare("INSERT INTO agenda (user_id, work_date) VALUES (?, ?)");
            $stmt->bind_param("is", $user_id, $work_date);
        }

        if ($stmt->execute()) {
            // Success
        } else {
            // Error
        }
        $stmt->close();
    }
}

// Fetch the user's agenda
$stmt = $conn->prepare("SELECT work_date FROM agenda WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$work_dates = [];
while ($row = $result->fetch_assoc()) {
    $work_dates[] = $row['work_date'];
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/agenda.css?v=1.01">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link href='https://fonts.googleapis.com/css?family=Libre Franklin' rel='stylesheet'>
    <title>Agenda - Working In The Arts</title>
    <script>
        function toggleWorkDay(date) {
            const form = document.getElementById('workDateForm');
            document.getElementById('work_date').value = date;
            form.submit();
        }

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelector('.iconNext').addEventListener('click', function() {
                changeMonth(1);
            });
            document.querySelector('.iconPrevious').addEventListener('click', function() {
                changeMonth(-1);
            });
        });

        function changeMonth(direction) {
            const currentMonth = new Date(document.getElementById('currentMonth').value + '-01');
            currentMonth.setMonth(currentMonth.getMonth() + direction);

            const month = currentMonth.getMonth() + 1;
            const year = currentMonth.getFullYear();
            const formattedMonth = month < 10 ? '0' + month : month;

            window.location.href = `agenda.php?month=${year}-${formattedMonth}`;
        }
    </script>
</head>
<body>
<div class="headerNav">
    <img src="images/LogoWITA.png" class="LogoWITA" alt="WorkingInTheArts logo">
    <img src="images/LogoBE.png" class="LogoBE" alt="Overheid Logo">
</div>
<div class="pageTitle">
    <h1>Agenda</h1>
    <a href="dashboard.php"><img src="images/iconBack.png" alt="" class="iconBack"></a>
</div>
<div class="pageText">
    <h3>Markeer je werkdagen om het overzicht te behouden.</h3>
</div>
<div class="monthSelection">
    <img src="images/iconPrevious.png" alt="" class="iconPrevious">
    <h2 class="month">
        <?php
        $current_month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
        echo date('F Y', strtotime($current_month . '-01'));
        ?>
    </h2>
    <img src="images/iconNext.png" alt="" class="iconNext">
</div>
<div class="calendar">
    <?php
    $days_in_month = date('t', strtotime($current_month . '-01'));
    $today = date('Y-m-d');

    for ($day = 1; $day <= $days_in_month; $day++) {
        $date = $current_month . '-' . str_pad($day, 2, '0', STR_PAD_LEFT);
        $class = '';

        if ($date == $today) {
            $class = 'today';
        } elseif (in_array($date, $work_dates)) {
            $class = ($date < $today) ? 'past-worked-day' : 'working-day';
        }

        echo "<div class='day $class' data-date='$date' onclick='toggleWorkDay(\"$date\")'>$day</div>";
    }
    ?>
</div>
<div class="legend">
    <h4 class="Ltoday">Vandaag</h4>
    <h4 class="Lwork">Ingepland</h4>
    <h4 class="Lworked">Gewerkte dag</h4>
    </div>
</div>
<form id="workDateForm" method="post" action="agenda.php">
    <input type="hidden" id="work_date" name="work_date">
</form>
<input type="hidden" id="currentMonth" value="<?php echo $current_month; ?>">

<div class="navbar">
    <div class="navIcons">
        <a href="data_entry.html"><img src="images/navWork.png" alt="" class="navWork"></a>
        <img src="images/navDashActive.png" alt="navDashActive" class="navDash">
        <a href="settings.php"><img src="images/navSettings.png" alt="navSettings" class="navSettings"></a>
    </div>
</div>
</body>
</html>
