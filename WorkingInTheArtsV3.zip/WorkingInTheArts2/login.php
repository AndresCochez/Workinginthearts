<?php
session_start();
include('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT user_id, name, job_type, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['email'] = $email;
            $_SESSION['job_type'] = $user['job_type'];

            if (!empty($user['job_type'])) {
                header("Location: dashboard.php");
                exit();
            } else {
                header("Location: job_selection.html");
                exit();
            }
        } else {
            echo "Invalid email or password.";
        }
    } else {
        echo "Invalid email or password.";
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/login.css?v=1.02">
    <link href='https://fonts.googleapis.com/css?family=Libre Franklin' rel='stylesheet'>
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <title>Inloggen - Working In The Arts</title>
</head>
<body>
    <div class="headerNav">
        <img src="images/LogoWITA.png" class="LogoWITA" alt="WorkingInTheArts logo">
        <img src="images/LogoBE.png" class="LogoBE" alt="Overheid Logo">
    </div>
    <img src="images/headerimg.png" alt="" class="headerimg">
    <div class="title">
    <h1>Welkom terug.</h1>
    <h2>Log je in op het Working in the Arts platform om zo je vooruitgang te bekijken.</h2>
    </div>
    <div class="dashboard">
        <div class="dash1">
            <form method="post" action="login.php">
                <h1 class="formTitle">Inloggen</h1>
                <div class="inputs">
                <div class="d1line1">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" placeholder="voorbeeld@email.com" required>
                </div>
                <div class="d1line1">
                    <label for="password">Wachtwoord</label>
                    <input type="password" name="password" id="password" placeholder="●●●●●●●" required>
                </div>
                </div>
                <div class="buttons">
                    <button type="submit" class="button">Login</button>
                    <a href="register.php" class="registerLink">Ik heb nog geen account.</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
